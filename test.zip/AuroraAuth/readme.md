# FastAPI App with Modular Aurora Auth

This project demonstrates a FastAPI application integrated with Aurora Auth (Keycloak) using a clean, modular package structure. The authentication logic is reusable and separated from the main application and deployment code.

## How to Run

1.  **Set Up Credentials:**
    -   Rename the `.env.example` file to `.env`.
    -   Open the `.env` file and replace `"your_actual_client_secret_goes_here"` with your real **Aurora SSO Client Secret**.
    -   Ensure `APP_BASE_URL` is set correctly for your environment (`http://127.0.0.1:8000` for local testing).

2.  **Install Dependencies:**
    ```bash
    pip install -r requirements.txt
    ```

3.  **Run Locally for Testing:**
    Use `uvicorn` to run the main application. This is great for development.
    ```bash
    uvicorn main:app --reload
    ```
    The app will be running at `http://127.0.0.1:8000`.

## How to Use the Authentication Flow

1.  **Start the Authentication:**
    Open your web browser and go to:
    **[http://127.0.0.1:8000/auth/authenticate](http://127.0.0.1:8000/auth/authenticate)**

2.  **Log In via Keycloak:**
    You will be redirected to the DBS Keycloak login page. Enter your credentials.

3.  **Get the Token:**
    After a successful login, Keycloak will redirect you back to the application's callback URL (`/auth/callback`). The application will exchange the code for a token and display the user information in a JSON response.

## For Ray Serve Deployment

To deploy this using Ray Serve, you would typically run a command like:

```bash
serve run main:serve_app