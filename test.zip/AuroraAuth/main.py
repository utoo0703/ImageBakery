"""
Main FastAPI app for Ray Serve deployment that uses the modular Aurora Auth package.
"""
import time
import uvicorn
from fastapi import FastAPI
from ray import serve

# Import the authentication router from our new package
from auth_package import router as auth_router

# --- Main Application ---
app = FastAPI(
    title="AskTrino with Modular Auth",
    description="A FastAPI app using a reusable Aurora Auth package.",
    version="2.0.0"
)

# Include the authentication router.
# This makes the /auth/authenticate and /auth/callback endpoints available.
app.include_router(auth_router.router)


# --- Endpoints Specific to the Main App ---
@app.get("/")
async def root():
    """
    Root endpoint for the main application.
    """
    return {
        "message": "✨ Welcome to the Main Application ✨",
        "authentication_start_point": "/auth/authenticate",
        "api_docs": "/docs"
    }


@app.get("/health", tags=["Health"])
async def health():
    """
    A simple health check endpoint.
    """
    return {
        "status": "ok",
        "timestamp": time.time()
    }

# ========================================
# RAY SERVE DEPLOYMENT
# ========================================

# The Ray Serve configuration remains in the main deployment script,
# keeping the auth package free of deployment-specific logic.
@serve.deployment(
    autoscaling_config={
        'min_replicas': 1,
        'max_replicas': 3,
        'target_ongoing_requests': 2.0,
    },
    ray_actor_options={'num_cpus': 0.5}
)
@serve.ingress(app)
class AskTrinoAuthApp:
    pass

# Create the Ray Serve app for deployment
serve_app = AskTrinoAuthApp.bind()

# Add a section to allow running locally with uvicorn for testing
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)