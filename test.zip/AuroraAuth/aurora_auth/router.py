"""
Contains the APIRouter with all Aurora Auth (OAuth2) endpoints.
"""
from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import RedirectResponse
import requests

# Import from our package's modules
from .. import config, schemas, utils

# Create an APIRouter. All endpoints here will be prefixed with /auth.
router = APIRouter(
    prefix="/auth",
    tags=["Aurora Authentication"]
)


@router.get("/authenticate")
async def authenticate_aurora():
    """
    Initiates the OAuth 2.0 Authorization Code Flow by redirecting the user to Keycloak.
    """
    # The callback URI must point to our /callback endpoint.
    CALLBACK_URI = f"{config.APP_BASE_URL}{router.prefix}/callback"

    auth_redirect_url = (
        f"{config.KEYCLOAK_AUTH_URL}"
        f"?client_id=aurora"
        f"&response_type=code"
        f"&scope=openid+profile+email"
        f"&redirect_uri={CALLBACK_URI}"
        # NOTE: For production, you should add a 'state' parameter for CSRF protection.
    )
    utils.logger.info(f"Redirecting user to Keycloak: {auth_redirect_url}")
    return RedirectResponse(url=auth_redirect_url)


@router.get("/callback", response_model=schemas.AuthResponse)
async def oauth_callback(request: Request, code: str = None, error: str = None):
    """
    Handles the redirect from Keycloak, exchanging the authorization code for an access token.
    """
    if error:
        error_desc = request.query_params.get('error_description', 'No description provided.')
        utils.logger.error(f"OAuth callback error: {error}. Description: {error_desc}")
        raise HTTPException(status_code=400, detail={"error": error, "details": error_desc})

    if not code:
        utils.logger.error("No authorization code received in callback.")
        raise HTTPException(status_code=400, detail={"error": "Authorization code missing."})

    utils.logger.info(f"Received authorization code: {code[:20]}...")

    # The CALLBACK_URI MUST EXACTLY MATCH the one used in the /authenticate request.
    CALLBACK_URI = f"{config.APP_BASE_URL}{router.prefix}/callback"

    data = {
        'grant_type': 'authorization_code',
        'client_id': 'aurora',
        'client_secret': config.AURORA_CLIENT_SECRET,
        'code': code,
        'redirect_uri': CALLBACK_URI
    }

    try:
        # WARNING: verify=False is insecure and should only be used in non-production
        # environments with self-signed certificates.
        token_response = requests.post(config.KEYCLOAK_TOKEN_URL, data=data, verify=False, timeout=30)
        token_response.raise_for_status()  # Raises an exception for 4xx/5xx responses

        token_data = token_response.json()
        access_token = token_data.get('access_token')

        if not access_token:
            utils.logger.error(f"No access token in Keycloak response: {token_response.text}")
            raise HTTPException(status_code=500, detail="Failed to get access token from Keycloak.")

        user_info = utils.decode_jwt_payload(access_token)
        utils.logger.info(f"✅ Authentication successful for user: {user_info.get('email', 'N/A')}")

        return schemas.AuthResponse(
            status="success",
            message="Authentication successful!",
            token_preview=f"{access_token[:50]}...",
            expires_in=token_data.get('expires_in'),
            user_info=user_info
        )

    except requests.exceptions.HTTPError as e:
        utils.logger.error(f"Token exchange failed: {e.response.status_code} - {e.response.text}")
        raise HTTPException(status_code=e.response.status_code, detail={"error": "Token exchange failed", "details": e.response.text})
    except requests.exceptions.RequestException as e:
        utils.logger.error(f"Network error during token exchange: {e}")
        raise HTTPException(status_code=500, detail={"error": "Network error during token exchange.", "details": str(e)})