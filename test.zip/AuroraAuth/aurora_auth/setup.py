from setuptools import setup, find_packages

with open('requirements.txt') as f:
    requirements = f.read().splitlines()

setup(
    name='aurora_auth_fastapi',
    version='1.0.4',
    author='Utsav Sarkae', 
    author_email='utsavusarkar@dbs.com', 
    description='A reusable FastAPI package for Aurora (Keycloak) OAuth2 authentication.',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='Browse ADA_AMLP / aurora-sso-poc - Bitbucket', 
    packages=find_packages(),
    install_requires=requirements,
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Framework :: FastAPI',
        'License :: OSI Approved :: MIT License', 
        'Operating System :: OS Independent',
        'Topic :: Software Development :: Libraries :: Application Frameworks',
    ],
    python_requires='>=3.8',
)
