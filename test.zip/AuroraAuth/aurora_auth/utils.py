"""
Helper functions for logging and JWT decoding.
"""
import logging
import json
import base64

# Setup a logger specific to the auth package
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("auth_package")

def decode_jwt_payload(access_token: str):
    """
    Decodes the payload of a JWT without verifying its signature.
    """
    try:
        # JWTs are composed of three parts separated by dots. The middle part is the payload.
        _, payload_encoded, _ = access_token.split('.')
        
        # The payload needs to be padded correctly for base64 decoding.
        payload_decoded = base64.urlsafe_b64decode(payload_encoded + '==').decode('utf-8')
        return json.loads(payload_decoded)
    except Exception as e:
        logger.error(f"Error decoding JWT payload: {e}")
        return {"error": "Invalid token or decode error"}