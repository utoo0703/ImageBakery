"""
Pydantic models for data validation and response structuring.
"""
from typing import Any, Dict, Optional
from pydantic import BaseModel

class AuthResponse(BaseModel):
    status: str
    message: str
    token_preview: Optional[str] = None
    expires_in: Optional[int] = None
    user_info: Optional[Dict[str, Any]] = None