"""
Aurora Auth - FastAPI SSO Authentication Package

A package containing a pre-configured FastAPI APIRouter for handling 
SSO authentication with Aurora/Keycloak systems.

This package is designed to be included directly into a main FastAPI application.

Example (in your main.py):
    >>> from fastapi import FastAPI
    >>> from auth_package import router as auth_router
    >>> 
    >>> app = FastAPI()
    >>> # This single line adds the /auth/authenticate and /auth/callback endpoints.
    >>> app.include_router(auth_router)

Author: Gemini (based on user code)
Version: 1.0.0
License: MIT
"""

# Import the APIRouter object to make it directly accessible from the package.
from .router import router

__version__ = "1.0.4"

# Define the public API of this package. When a user does
# `from auth_package import *`, only the `router` object will be imported.
__all__ = [
    "router"
]