"""
Loads and holds all configuration variables from environment variables.
"""
import os
from dotenv import load_dotenv

# Load variables from a .env file into the environment
load_dotenv()

# --- Keycloak & Aurora Credentials ---
AURORA_CLIENT_SECRET = os.getenv('UAT_AURORA_SSO_CLIENT_SECRET', "").strip()
KEYCLOAK_TOKEN_URL = "https://ada-sso-keycloak.edsf-pas.ocp.uat.dbs.com/realms/H3-ADAK8S/protocol/openid-connect/token"
KEYCLOAK_AUTH_URL = "https://ada-sso-keycloak.edsf-pas.ocp.uat.dbs.com/realms/H3-ADAK8S/protocol/openid-connect/auth"

# --- Application URL ---
# This is the public-facing URL of your application.
# It is CRITICAL that this matches the URL registered in Keycloak's redirect URIs.
APP_BASE_URL = os.getenv("APP_BASE_URL", "http://127.0.0.1:8000")

# Basic check to ensure the secret is loaded
if not AURORA_CLIENT_SECRET:
    print("⚠️ WARNING: UAT_AURORA_SSO_CLIENT_SECRET is not set. Authentication will fail.")